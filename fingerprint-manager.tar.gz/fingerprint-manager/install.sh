#!/bin/bash

USERNAME=$(whoami)
SCRIPT_DIR="/home/$USERNAME/.local/bin"
DESKTOP_DIR="/home/$USERNAME/.local/share/applications"

mkdir -p "$SCRIPT_DIR" "$DESKTOP_DIR"
cp fingerprint-manager.sh "$SCRIPT_DIR/"
chmod +x "$SCRIPT_DIR/fingerprint-manager.sh"

# Replace placeholder in .desktop file
sed "s|/home/yourusername|/home/$USERNAME|g" fingerprint-manager.desktop > "$DESKTOP_DIR/fingerprint-manager.desktop"

echo "✅ Fingerprint Manager installed!"
